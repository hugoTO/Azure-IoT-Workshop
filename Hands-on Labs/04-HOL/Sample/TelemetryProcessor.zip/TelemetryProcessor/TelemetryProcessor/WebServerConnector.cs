﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.WindowsAzure;
using Newtonsoft.Json;

namespace TelemetryEPHostConsoleApp
{
    class WebServerConnector
    {
        public WebServerConnector()
        { }

        public string PostTelemetryMessage(TelemetryMessage telemetryMessage)
        {
            string _realTimeDataFeedInURI = Program._webServerUrl;

            try
            {
                string postData = "deviceId=" + telemetryMessage.deviceId + "&" +
                                    "msgId=" + telemetryMessage.msgId + "&" +
                                    "temperature=" + telemetryMessage.temperature + "&" +
                                    "humidity=" + telemetryMessage.humidity + "&" +
                                    "time=" + telemetryMessage.time;

                var data = Encoding.UTF8.GetBytes(postData);

                var request = (HttpWebRequest)WebRequest.Create(_realTimeDataFeedInURI);
                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
                request.ContentLength = data.Length;

                using (var stream = request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }

                var response = (HttpWebResponse)request.GetResponse();
                return new StreamReader(response.GetResponseStream()).ReadToEnd();
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public async void PostTelemetryMessageToPowerBIAsync(string data)
        {
            try
            {
                //Console.WriteLine(String.Format("Making POST request with data: {0}", data));

                WebRequest request = WebRequest.Create(Program._powerbiPushUrl);
                request.Method = "POST";

                // Prepare request for sending
                byte[] byteArray = Encoding.UTF8.GetBytes(data);
                request.ContentLength = byteArray.Length;

                // Get the request stream.
                Stream dataStream = request.GetRequestStream();

                // Write the data to the request stream.
                dataStream.Write(byteArray, 0, byteArray.Length);

                // Close the Stream object.
                dataStream.Close();

                // Get the response.
                WebResponse response = await request.GetResponseAsync();

                // Display the status.
                //Console.WriteLine(String.Format("Service response: {0}", ((HttpWebResponse)response).StatusCode));

                // Get the stream containing content returned by the server.
                dataStream = response.GetResponseStream();

                // Open the stream using a StreamReader for easy access.
                StreamReader reader = new StreamReader(dataStream);

                // Read the content.
                string responseFromServer = reader.ReadToEnd();

                // Display the content.
                Console.WriteLine(responseFromServer);

                // Clean up the streams.
                reader.Close();
                dataStream.Close();
                response.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.UtcNow.ToString() + ": Exception : " + ex.Message);
            }
        }
    }
}
