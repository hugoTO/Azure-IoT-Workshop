﻿using Microsoft.ServiceBus.Messaging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelemetryEPHostConsoleApp
{
    class Program
    {
        public static string _webServerUrl { get; set; }
        public static string _powerbiPushUrl { get; set; }

        static void Main(string[] args)
        {
            Console.WriteLine("Console App for Telemetry Event Processor Host...\n");

            /* Load the settings from App.config */
            string isProduction = ConfigurationManager.AppSettings["WebServer.isProduction"];
            if (isProduction.Equals("1"))
                _webServerUrl = ConfigurationManager.AppSettings["WebServer.Production"];
            else
                _webServerUrl = ConfigurationManager.AppSettings["WebServer.Localhost"];

            Console.WriteLine("_webServerUrl={0}\n", _webServerUrl);

            // Power BI
            _powerbiPushUrl = ConfigurationManager.AppSettings["PowerBI.API"];
            Console.WriteLine("_powerbiPushUrl={0}\n", _powerbiPushUrl);

            // IoT Hub
            string iotHubConnectionString = ConfigurationManager.AppSettings["IoTHub.ConnectionString"];
            Console.WriteLine("iotHubConnectionString={0}\n", iotHubConnectionString);

            string eventHubPath = "messages/events";// It's hard-coded for IoT Hub
            string consumerGroupName = "telemetrypush";// It's hard-coded for this workshop

            // Storage Account
            string storageAccountConnectionString = ConfigurationManager.AppSettings["StorageAccount.ConnectionString"];
            Console.WriteLine("storageAccountConnectionString={0}\n", storageAccountConnectionString);

            string eventProcessorHostName = "eventprocessorhost";
            string leaseName = eventProcessorHostName;

            EventProcessorHost eventProcessorHost = new EventProcessorHost(
                eventProcessorHostName,
                eventHubPath,
                consumerGroupName,
                iotHubConnectionString,
                storageAccountConnectionString,
                leaseName);

            Console.WriteLine("Registering EventProcessor...");

            var options = new EventProcessorOptions
            {
                InitialOffsetProvider = (partitionId) => DateTime.UtcNow
            };
            options.ExceptionReceived += (sender, e) => { Console.WriteLine(e.Exception); };
            eventProcessorHost.RegisterEventProcessorAsync<TelemetryEventProcessor>(options).Wait();

            Console.WriteLine("Receiving. Press enter key to stop worker.");
            Console.ReadLine();
            eventProcessorHost.UnregisterEventProcessorAsync().Wait();

        }
    }
}
