﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RulesBlobConsoleApp
{
    class DeviceRule
    {
        public string SensorType { get; set; }
        public double TemperatureThreshold { get; set; }
    }
}
