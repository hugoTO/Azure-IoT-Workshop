// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. 

#ifndef UTILITY_H
#define UTILITY_H

typedef struct _c2d_command_
{
    const char *command;
    const char *value;
    const char *time;

} C2DCommand;

void parseTwinMessage(DEVICE_TWIN_UPDATE_STATE, const char *);
void parseC2DCommand(const char *);
bool isDeviceOff();

bool readMessage(int, char *);

void SensorInit(void);

void blinkLED(void);
void blinkSendConfirmation(void);
int getInterval(void);

#endif /* UTILITY_H */